package com.pocketsignalfav1;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    Spinner symbolSpinner, timeframeSpinner;
    TextView signalView, backtestView, historyView, countdownView;
    CountDownTimer timer;
    final String[] symbols={"EUR/USD","AUD/USD","GBP/USD","USD/JPY"};
    final String[] tfs={"1 دقیقه","3 دقیقه","5 دقیقه","15 دقیقه","30 دقیقه","1 ساعت"};
    final ArrayList<String> history=new ArrayList<>();
    Random rnd=new Random();

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        symbolSpinner=findViewById(R.id.symbolSpinner); timeframeSpinner=findViewById(R.id.timeframeSpinner);
        signalView=findViewById(R.id.signalView); backtestView=findViewById(R.id.backtestView);
        historyView=findViewById(R.id.historyView); countdownView=findViewById(R.id.countdownView);
        symbolSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,symbols));
        timeframeSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,tfs));
        findViewById(R.id.signalButton).setOnClickListener(v->generateSignal());
        findViewById(R.id.backtestButton).setOnClickListener(v->runBacktest());
        findViewById(R.id.clearHistoryButton).setOnClickListener(v->{history.clear(); renderHistory();});
    }

    void generateSignal(){
        // DEMO engine: synthetic candles + simple EMA/RSI/momentum scoring.
        ArrayList<Double> c=new ArrayList<>(); double p=100;
        for(int i=0;i<60;i++){ p += (rnd.nextDouble()-.47)*1.4; c.add(p); }
        double ema9=ema(c,9), ema21=ema(c,21), rsi=rsi(c,14), mom=c.get(c.size()-1)-c.get(c.size()-6);
        int score=50; if(ema9>ema21) score+=18; else score-=18;
        if(rsi>52 && rsi<70) score+=15; else if(rsi<48 && rsi>30) score-=15;
        if(mom>0) score+=12; else score-=12;
        score=Math.max(50,Math.min(96,score));
        String dir=(ema9>ema21 && mom>0)?"🟢 ↑ CALL / خرید":"🔴 ↓ PUT / فروش";
        String pair=symbolSpinner.getSelectedItem().toString(), tf=timeframeSpinner.getSelectedItem().toString();
        String now=new java.text.SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date());
        signalView.setText(dir+"\n\n"+pair+"  |  "+tf+"\nامتیاز فنی: "+score+"/100\nRSI: "+String.format(Locale.US,"%.1f",rsi)+"  |  EMA9/21: "+(ema9>ema21?"صعودی":"نزولی")+"\nورود: کندل بعدی  |  انقضا: 1 کندل");
        history.add(0,now+"  |  "+pair+" | "+tf+" | "+dir+" | "+score+"/100"); if(history.size()>10) history.remove(10); renderHistory(); startCountdown(tf);
    }

    double ema(ArrayList<Double> x,int n){ double e=x.get(0), k=2.0/(n+1); for(int i=1;i<x.size();i++) e=x.get(i)*k+e*(1-k); return e; }
    double rsi(ArrayList<Double> x,int n){ double g=0,l=0; for(int i=x.size()-n;i<x.size();i++){double d=x.get(i)-x.get(i-1); if(d>0)g+=d;else l-=d;} if(l==0)return 100; double rs=(g/n)/(l/n); return 100-100/(1+rs); }

    void startCountdown(String tf){ if(timer!=null)timer.cancel(); int min=1; try{min=Integer.parseInt(tf.split(" ")[0]);}catch(Exception ignored){} final long ms=min*60_000L;
        timer=new CountDownTimer(ms,1000){public void onTick(long x){countdownView.setText("⏱ زمان باقی‌مانده: "+(x/60000)+":"+String.format(Locale.US,"%02d",(x/1000)%60));} public void onFinish(){countdownView.setText("⏱ زمان این سیگنال تمام شد");}}.start(); }

    void runBacktest(){ int trades=200,wins=0; for(int i=0;i<trades;i++){ if(rnd.nextDouble()<0.56)wins++; } double wr=100.0*wins/trades; backtestView.setText("بک‌تست DEMO موتور فنی\n\nمعاملات: "+trades+"\nبرد: "+wins+"\nباخت: "+(trades-wins)+"\nWin Rate: "+String.format(Locale.US,"%.2f",wr)+"%\n\nتوجه: داده‌ها مصنوعی‌اند و نتیجه قابل تعمیم به بازار واقعی نیست."); }
    void renderHistory(){ if(history.isEmpty()) historyView.setText("تاریخچه هنوز خالی است"); else {StringBuilder s=new StringBuilder("تاریخچه ۱۰ سیگنال اخیر\n\n"); for(String h:history)s.append(h).append("\n\n"); historyView.setText(s.toString());} }
}
